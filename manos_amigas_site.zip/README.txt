INSTRUCCIONES PARA PUBLICAR
1) Extrae los archivos en una carpeta.
2) Abre index.html en tu navegador para ver el sitio localmente.
3) Para publicar en Internet puedes:
   - Subir la carpeta a GitHub y usar GitHub Pages.
   - Subir a Netlify o Vercel (arrastrar y soltar la carpeta).
   - Subir a cualquier hosting compartido (cPanel).
4) Antes de publicar, reemplaza el email 'pedidos@manosamigas.sv' por tu email real en script.js.
5) Nota sobre los iframes: algunos sitios no permiten ser embebidos. Si las páginas de Farmacias/La Colonia bloquean el iframe, los botones abrirán la página en una nueva pestaña.
6) Para recibir pedidos automáticamente en un servidor real, necesitarás un backend (ej. una función serverless que reciba POST). Puedo ayudarte a crear un ejemplo en Node.js o PHP.
